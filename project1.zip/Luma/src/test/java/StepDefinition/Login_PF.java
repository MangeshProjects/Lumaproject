package StepDefinition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.LoginPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pagefactory.Loginpage_PF;

public class Login_PF {
	
	WebDriver driver= null;
	Loginpage_PF login;
	
	
	@Given("User is on the login page.")
	public void user_is_on_the_login_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Inside step-User is on the login page");
		  WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		  driver.get("https://magento.softwaretestingboard.com/");
		  driver.manage().window().maximize();
		  
	    
	}

	@When("^User enters valid (.*) and (.*)$")
	public void user_enters_valid_username_and_password(String username,String password) {
	    // Write code here that turns the phrase above into concrete actions
		
		login = new Loginpage_PF(driver);
		System.out.println("Inside step-User enters valid username and password.");
		driver.findElement(By.xpath("(//a[contains(text(),'Sign In')])[1]")).click();
		login.enterusername(username);
		login.enterpassword(password);
		//driver.findElement(By.id("email")).sendKeys(username);
		//driver.findElement(By.id("pass")).sendKeys(password);
		
	    
	}

	@And("User clicks on the submit button")
	public void user_clicks_on_the_submit_button() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Inside step-User clicks on the submit button");
		login.Clickonbtn();;
		//driver.findElement(By.id("send2")).click();
	    
	}

	@Then("user will be navigated to the home page.")
	public void user_will_be_navigated_to_the_home_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Inside step-user will be navigated to the home page.");
		driver.quit();
	    
	}

}
